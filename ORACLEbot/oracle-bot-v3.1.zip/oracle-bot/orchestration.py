"""
ORACLE BOT - Multi-Framework Orchestration Configs
===================================================
Ready-to-use configurations for:
- AutoGen (Microsoft)
- LangGraph (LangChain)
- CrewAI
- Custom Python orchestration

Each config uses the modular prompts from prompts.py
"""

from prompts import get_agent_prompt, AGENT_ORDER, SHARED_CONTRACT

# ═══════════════════════════════════════════════════════════════════════════════
# AUTOGEN CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

def get_autogen_config(llm_config: dict = None):
    """
    Generate AutoGen agent configurations.
    
    Usage:
        from autogen import AssistantAgent, UserProxyAgent
        from orchestration import get_autogen_config
        
        config = get_autogen_config(llm_config={"model": "gpt-4"})
        agents = [AssistantAgent(**cfg) for cfg in config["agents"]]
    """
    
    if llm_config is None:
        llm_config = {
            "config_list": [{"model": "gpt-4", "api_key": "YOUR_KEY"}],
            "temperature": 0.7,
        }
    
    agents_config = []
    
    for agent_name in AGENT_ORDER:
        agents_config.append({
            "name": agent_name,
            "system_message": get_agent_prompt(agent_name),
            "llm_config": llm_config,
            "human_input_mode": "NEVER",
            "max_consecutive_auto_reply": 1,
        })
    
    return {
        "agents": agents_config,
        "execution_order": AGENT_ORDER,
        "group_chat_config": {
            "agents": AGENT_ORDER,
            "messages": [],
            "max_round": len(AGENT_ORDER) + 2,  # One round per agent + buffer
            "speaker_selection_method": "round_robin",  # Sequential execution
        }
    }


AUTOGEN_EXAMPLE = """
# ═══════════════════════════════════════════════════════════════════════════════
# AUTOGEN USAGE EXAMPLE
# ═══════════════════════════════════════════════════════════════════════════════

from autogen import AssistantAgent, GroupChat, GroupChatManager
from orchestration import get_autogen_config

# 1. Get configuration
config = get_autogen_config(llm_config={
    "config_list": [{"model": "gpt-4", "api_key": os.environ["OPENAI_API_KEY"]}],
    "temperature": 0.7,
})

# 2. Create agents
agents = []
for agent_cfg in config["agents"]:
    agents.append(AssistantAgent(**agent_cfg))

# 3. Create group chat with sequential execution
group_chat = GroupChat(
    agents=agents,
    messages=[],
    max_round=10,
    speaker_selection_method="round_robin"
)

# 4. Create manager
manager = GroupChatManager(
    groupchat=group_chat,
    llm_config=config["agents"][0]["llm_config"]
)

# 5. Run ORACLE cycle
user_query = "Design a distributed caching system..."
agents[0].initiate_chat(manager, message=user_query)
"""


# ═══════════════════════════════════════════════════════════════════════════════
# LANGGRAPH CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

def get_langgraph_config():
    """
    Generate LangGraph state machine configuration.
    
    Usage:
        from langgraph.graph import StateGraph
        from orchestration import get_langgraph_config
        
        config = get_langgraph_config()
        graph = StateGraph(config["state_schema"])
        for node in config["nodes"]:
            graph.add_node(node["name"], node["function"])
    """
    
    return {
        "state_schema": {
            "user_query": str,
            "context": dict,  # {agent_name: output}
            "current_agent": str,
            "cycle_complete": bool,
            "confidence": float,
            "open_obligations": list,
        },
        
        "nodes": [
            {
                "name": agent_name,
                "prompt": get_agent_prompt(agent_name),
                "input_keys": ["user_query", "context"],
                "output_key": agent_name.lower() + "_output",
            }
            for agent_name in AGENT_ORDER
        ],
        
        "edges": [
            ("DECOMPOSER", "EXPLORER"),
            ("EXPLORER", "CRITIC"),
            ("CRITIC", "BUILDER"),
            ("BUILDER", "INTEGRATOR"),
            ("INTEGRATOR", "__end__"),
        ],
        
        "conditional_edges": {
            "INTEGRATOR": {
                "condition": "confidence < 0.5",
                "true_target": "DECOMPOSER",  # Re-run cycle
                "false_target": "__end__",
            }
        }
    }


LANGGRAPH_EXAMPLE = """
# ═══════════════════════════════════════════════════════════════════════════════
# LANGGRAPH USAGE EXAMPLE
# ═══════════════════════════════════════════════════════════════════════════════

from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from orchestration import get_langgraph_config

# 1. Get configuration
config = get_langgraph_config()

# 2. Define state
class OracleState(TypedDict):
    user_query: str
    context: dict
    current_agent: str
    cycle_complete: bool

# 3. Create LLM
llm = ChatOpenAI(model="gpt-4", temperature=0.7)

# 4. Create node functions
def make_agent_node(agent_name, prompt):
    def node_fn(state):
        full_prompt = f"{prompt}\\n\\nUser Query: {state['user_query']}\\n\\nContext: {state['context']}"
        response = llm.invoke(full_prompt)
        state["context"][agent_name] = response.content
        return state
    return node_fn

# 5. Build graph
graph = StateGraph(OracleState)

for node in config["nodes"]:
    graph.add_node(
        node["name"],
        make_agent_node(node["name"], node["prompt"])
    )

# 6. Add edges (sequential)
graph.set_entry_point("DECOMPOSER")
for source, target in config["edges"]:
    if target == "__end__":
        graph.add_edge(source, END)
    else:
        graph.add_edge(source, target)

# 7. Compile and run
app = graph.compile()
result = app.invoke({
    "user_query": "Design a distributed caching system...",
    "context": {},
    "current_agent": "DECOMPOSER",
    "cycle_complete": False
})
"""


# ═══════════════════════════════════════════════════════════════════════════════
# CREWAI CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

def get_crewai_config():
    """
    Generate CrewAI agent and task configurations.
    """
    
    agents = []
    tasks = []
    
    for i, agent_name in enumerate(AGENT_ORDER):
        # Agent definition
        agents.append({
            "role": agent_name,
            "goal": f"Execute the {agent_name} role in the ORACLE verification circuit",
            "backstory": get_agent_prompt(agent_name)[:500] + "...",  # CrewAI has length limits
            "verbose": True,
            "allow_delegation": False,
        })
        
        # Task definition
        tasks.append({
            "description": f"Execute {agent_name} analysis on the given query",
            "agent": agent_name,
            "expected_output": f"YAML-formatted {agent_name} output following the specification",
            "context": [tasks[i-1]] if i > 0 else [],  # Chain tasks
        })
    
    return {
        "agents": agents,
        "tasks": tasks,
        "process": "sequential",  # Not hierarchical
    }


CREWAI_EXAMPLE = """
# ═══════════════════════════════════════════════════════════════════════════════
# CREWAI USAGE EXAMPLE
# ═══════════════════════════════════════════════════════════════════════════════

from crewai import Agent, Task, Crew, Process
from orchestration import get_crewai_config

# 1. Get configuration
config = get_crewai_config()

# 2. Create agents
agents = [Agent(**cfg) for cfg in config["agents"]]

# 3. Create tasks
tasks = []
for i, task_cfg in enumerate(config["tasks"]):
    task_cfg["agent"] = agents[i]
    if i > 0:
        task_cfg["context"] = [tasks[i-1]]
    tasks.append(Task(**task_cfg))

# 4. Create crew
crew = Crew(
    agents=agents,
    tasks=tasks,
    process=Process.sequential,
    verbose=True
)

# 5. Run
result = crew.kickoff(inputs={"query": "Design a distributed caching system..."})
"""


# ═══════════════════════════════════════════════════════════════════════════════
# CUSTOM PYTHON ORCHESTRATION (No framework dependency)
# ═══════════════════════════════════════════════════════════════════════════════

CUSTOM_ORCHESTRATOR = """
# ═══════════════════════════════════════════════════════════════════════════════
# CUSTOM ORCHESTRATOR - No framework dependencies
# ═══════════════════════════════════════════════════════════════════════════════

import json
from typing import Dict, Any
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class OracleState:
    user_query: str
    context: Dict[str, str] = field(default_factory=dict)
    confidence: float = 0.0
    open_obligations: list = field(default_factory=list)
    cycle_count: int = 0
    max_cycles: int = 3

class OracleOrchestrator:
    def __init__(self, llm_client, prompts_module):
        self.llm = llm_client
        self.prompts = prompts_module
        self.agent_order = prompts_module.AGENT_ORDER
    
    def run_agent(self, agent_name: str, state: OracleState) -> str:
        # Build prompt with context
        prompt = self.prompts.get_agent_prompt(agent_name)
        context_str = json.dumps(state.context, indent=2)
        
        full_prompt = f'''
{prompt}

USER QUERY:
{state.user_query}

PREVIOUS AGENT OUTPUTS:
{context_str}

NOW EXECUTE YOUR ROLE:
'''
        # Call LLM
        response = self.llm.complete(full_prompt)
        return response
    
    def extract_confidence(self, integrator_output: str) -> float:
        # Parse confidence from INTEGRATOR output
        import re
        match = re.search(r'overall:\\s*([\\d.]+)', integrator_output)
        if match:
            return float(match.group(1))
        match = re.search(r'confidence:\\s*([\\d.]+)', integrator_output)
        if match:
            return float(match.group(1))
        return 0.5  # Default
    
    def run_cycle(self, state: OracleState) -> OracleState:
        state.cycle_count += 1
        
        for agent_name in self.agent_order:
            print(f"[ORACLE] Running {agent_name}...")
            output = self.run_agent(agent_name, state)
            state.context[agent_name] = output
            
            if agent_name == "INTEGRATOR":
                state.confidence = self.extract_confidence(output)
        
        return state
    
    def run(self, user_query: str) -> OracleState:
        state = OracleState(user_query=user_query)
        
        while state.cycle_count < state.max_cycles:
            state = self.run_cycle(state)
            
            if state.confidence >= 0.5:
                print(f"[ORACLE] Confidence {state.confidence:.2f} >= 0.5, delivering result")
                break
            else:
                print(f"[ORACLE] Confidence {state.confidence:.2f} < 0.5, re-running cycle")
                state.context = {}  # Reset for new cycle
        
        return state

# Usage:
# from prompts import *
# orchestrator = OracleOrchestrator(my_llm_client, prompts_module)
# result = orchestrator.run("Design a distributed caching system...")
# print(result.context["INTEGRATOR"])
"""


# ═══════════════════════════════════════════════════════════════════════════════
# STATE SCHEMA FOR ALL FRAMEWORKS
# ═══════════════════════════════════════════════════════════════════════════════

STATE_SCHEMA = {
    "type": "object",
    "properties": {
        "user_query": {"type": "string", "description": "Original user request"},
        "context": {
            "type": "object",
            "description": "Agent outputs keyed by agent name",
            "properties": {
                "DECOMPOSER": {"type": "string"},
                "EXPLORER": {"type": "string"},
                "CRITIC": {"type": "string"},
                "BUILDER": {"type": "string"},
                "INTEGRATOR": {"type": "string"},
            }
        },
        "metadata": {
            "type": "object",
            "properties": {
                "cycle_id": {"type": "string"},
                "cycle_count": {"type": "integer"},
                "start_time": {"type": "string", "format": "date-time"},
                "elapsed_seconds": {"type": "number"},
            }
        },
        "metrics": {
            "type": "object",
            "properties": {
                "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                "tier_I_claims": {"type": "integer"},
                "tier_II_claims": {"type": "integer"},
                "scope_leaks": {"type": "integer"},
                "progress_score": {"type": "number"},
            }
        },
        "control": {
            "type": "object",
            "properties": {
                "current_agent": {"type": "string", "enum": AGENT_ORDER},
                "cycle_complete": {"type": "boolean"},
                "should_iterate": {"type": "boolean"},
                "termination_reason": {"type": "string"},
            }
        }
    },
    "required": ["user_query", "context"]
}


# ═══════════════════════════════════════════════════════════════════════════════
# EXPORTS
# ═══════════════════════════════════════════════════════════════════════════════

__all__ = [
    'get_autogen_config',
    'get_langgraph_config', 
    'get_crewai_config',
    'STATE_SCHEMA',
    'AUTOGEN_EXAMPLE',
    'LANGGRAPH_EXAMPLE',
    'CREWAI_EXAMPLE',
    'CUSTOM_ORCHESTRATOR',
]


if __name__ == "__main__":
    print("ORACLE BOT - Multi-Framework Orchestration Configs")
    print("=" * 50)
    print("\nAvailable configurations:")
    print("  - get_autogen_config()  → AutoGen (Microsoft)")
    print("  - get_langgraph_config() → LangGraph (LangChain)")
    print("  - get_crewai_config()   → CrewAI")
    print("  - CUSTOM_ORCHESTRATOR   → Pure Python (no deps)")
    print("\nState schema available in STATE_SCHEMA")
    print("\nExample code in *_EXAMPLE constants")
