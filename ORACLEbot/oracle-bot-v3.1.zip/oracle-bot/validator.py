"""
ORACLE BOT - Automated Tier I Validator
========================================
Hooks into the ORACLE loop to verify Tier I claims computationally.

This validator:
1. Extracts code/math from BUILDER output
2. Executes in sandboxed environment
3. Compares results to claimed outputs
4. Promotes successful validations to Tier I
5. Flags failures for CRITIC re-review

Usage:
    validator = TierIValidator()
    result = validator.validate(builder_output)
    
Kill-Switches:
- Continuum assumption without limit proof → REJECT
- Unjustified discrete-to-continuous jump → REJECT  
- Missing computational certificate → DEMOTE to Tier II
"""

import re
import json
import subprocess
import tempfile
import os
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# VALIDATION RESULT TYPES
# ═══════════════════════════════════════════════════════════════════════════════

class ValidationStatus(Enum):
    PASSED = "PASSED"           # Tier I confirmed
    FAILED = "FAILED"           # Computation returned wrong result
    ERROR = "ERROR"             # Execution error
    TIMEOUT = "TIMEOUT"         # Exceeded time limit
    UNSAFE = "UNSAFE"           # Potentially dangerous code detected
    DEMOTED = "DEMOTED"         # Demoted from Tier I to Tier II
    KILL_SWITCH = "KILL_SWITCH" # Triggered automatic rejection


@dataclass
class ValidationResult:
    """Result of a single validation check."""
    claim_id: str
    claim_text: str
    original_tier: str
    validated_tier: str
    status: ValidationStatus
    expected: Any
    actual: Any
    execution_time_ms: float
    error_message: Optional[str] = None
    kill_switch_triggered: Optional[str] = None


@dataclass 
class ValidatorReport:
    """Full validation report for a BUILDER output."""
    timestamp: str
    total_claims: int
    tier_I_validated: int
    tier_I_failed: int
    tier_II_demoted: int
    kill_switches_triggered: int
    results: List[ValidationResult] = field(default_factory=list)
    overall_status: str = "PENDING"
    
    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "total_claims": self.total_claims,
            "tier_I_validated": self.tier_I_validated,
            "tier_I_failed": self.tier_I_failed,
            "tier_II_demoted": self.tier_II_demoted,
            "kill_switches_triggered": self.kill_switches_triggered,
            "overall_status": self.overall_status,
            "results": [
                {
                    "claim_id": r.claim_id,
                    "claim_text": r.claim_text[:100] + "..." if len(r.claim_text) > 100 else r.claim_text,
                    "original_tier": r.original_tier,
                    "validated_tier": r.validated_tier,
                    "status": r.status.value,
                    "execution_time_ms": r.execution_time_ms,
                    "error_message": r.error_message,
                    "kill_switch": r.kill_switch_triggered
                }
                for r in self.results
            ]
        }


# ═══════════════════════════════════════════════════════════════════════════════
# KILL-SWITCH PATTERNS (RH-Specialized)
# ═══════════════════════════════════════════════════════════════════════════════

KILL_SWITCHES = {
    "CONTINUUM_ASSUMPTION": {
        "patterns": [
            r"assume.*continuum",
            r"by.*continuum.*hypothesis",
            r"CH\s+implies",
            r"under\s+CH",
        ],
        "message": "Continuum Hypothesis assumed without explicit Tier III label"
    },
    "DISCRETE_TO_CONTINUOUS": {
        "patterns": [
            r"taking.*limit.*without.*proof",
            r"as\s+n\s*→\s*∞\s+therefore",
            r"in\s+the\s+limit.*we\s+have",
        ],
        "message": "Unjustified discrete-to-continuous jump without limit proof"
    },
    "RH_EQUIVALENCE_CLAIM": {
        "patterns": [
            r"equivalent\s+to\s+(RH|Riemann)",
            r"proves?\s+(RH|Riemann\s+Hypothesis)",
            r"implies\s+(RH|Riemann)",
        ],
        "message": "RH equivalence claimed without explicit Tier II + falsification protocol"
    },
    "INFINITE_SERIES_CONVERGENCE": {
        "patterns": [
            r"sum.*converges.*therefore",
            r"∑.*=.*\d+.*therefore",
        ],
        "message": "Infinite series convergence asserted without convergence proof"
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# CODE SAFETY CHECKS
# ═══════════════════════════════════════════════════════════════════════════════

UNSAFE_PATTERNS = [
    r"import\s+os",
    r"import\s+subprocess",
    r"import\s+sys",
    r"exec\s*\(",
    r"eval\s*\(",
    r"__import__",
    r"open\s*\(",
    r"file\s*\(",
    r"input\s*\(",
    r"raw_input",
    r"compile\s*\(",
    r"globals\s*\(",
    r"locals\s*\(",
    r"getattr\s*\(",
    r"setattr\s*\(",
    r"delattr\s*\(",
    r"import\s+shutil",
    r"import\s+socket",
    r"import\s+requests",
    r"import\s+urllib",
]


# ═══════════════════════════════════════════════════════════════════════════════
# TIER I VALIDATOR CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class TierIValidator:
    """
    Automated validator for Tier I computational claims.
    
    Validates claims by:
    1. Extracting testable code/assertions
    2. Running in sandboxed environment
    3. Comparing results to expected values
    4. Checking for kill-switch violations
    """
    
    def __init__(self, timeout_seconds: int = 30, max_memory_mb: int = 512):
        self.timeout = timeout_seconds
        self.max_memory = max_memory_mb
        self.allowed_imports = [
            "math", "numpy", "scipy", "sympy", "decimal", 
            "fractions", "itertools", "functools", "collections",
            "typing", "dataclasses", "enum"
        ]
    
    def validate(self, builder_output: str) -> ValidatorReport:
        """
        Validate all Tier I claims in BUILDER output.
        
        Args:
            builder_output: Raw YAML/text output from BUILDER agent
            
        Returns:
            ValidatorReport with all validation results
        """
        report = ValidatorReport(
            timestamp=datetime.now().isoformat(),
            total_claims=0,
            tier_I_validated=0,
            tier_I_failed=0,
            tier_II_demoted=0,
            kill_switches_triggered=0
        )
        
        # 1. Check for kill-switch violations in full text
        kill_switch_results = self._check_kill_switches(builder_output)
        for result in kill_switch_results:
            report.results.append(result)
            report.kill_switches_triggered += 1
        
        if report.kill_switches_triggered > 0:
            report.overall_status = "KILL_SWITCH_TRIGGERED"
            return report
        
        # 2. Extract claims and validation logs
        claims = self._extract_claims(builder_output)
        validation_logs = self._extract_validation_logs(builder_output)
        
        report.total_claims = len(claims)
        
        # 3. Validate each claim
        for claim in claims:
            result = self._validate_claim(claim, validation_logs)
            report.results.append(result)
            
            if result.status == ValidationStatus.PASSED:
                report.tier_I_validated += 1
            elif result.status in [ValidationStatus.FAILED, ValidationStatus.ERROR]:
                report.tier_I_failed += 1
            elif result.status == ValidationStatus.DEMOTED:
                report.tier_II_demoted += 1
        
        # 4. Determine overall status
        if report.tier_I_failed > 0:
            report.overall_status = "VALIDATION_FAILED"
        elif report.tier_II_demoted > 0:
            report.overall_status = "PARTIAL_VALIDATION"
        elif report.tier_I_validated == report.total_claims:
            report.overall_status = "FULLY_VALIDATED"
        else:
            report.overall_status = "NO_TESTABLE_CLAIMS"
        
        return report
    
    def _check_kill_switches(self, text: str) -> List[ValidationResult]:
        """Check for kill-switch pattern violations."""
        results = []
        
        for switch_name, switch_config in KILL_SWITCHES.items():
            for pattern in switch_config["patterns"]:
                if re.search(pattern, text, re.IGNORECASE):
                    results.append(ValidationResult(
                        claim_id=f"KILL_{switch_name}",
                        claim_text=f"Kill-switch triggered: {switch_name}",
                        original_tier="I",
                        validated_tier="REJECTED",
                        status=ValidationStatus.KILL_SWITCH,
                        expected="No violation",
                        actual=f"Pattern matched: {pattern}",
                        execution_time_ms=0,
                        kill_switch_triggered=switch_config["message"]
                    ))
                    break  # One match per switch is enough
        
        return results
    
    def _extract_claims(self, text: str) -> List[Dict[str, Any]]:
        """Extract Tier I claims from BUILDER output."""
        claims = []
        
        # Pattern: [Tier I] followed by claim
        tier_i_pattern = r'\[Tier\s*I\]\s*(.+?)(?=\[Tier|\n\n|$)'
        matches = re.findall(tier_i_pattern, text, re.DOTALL | re.IGNORECASE)
        
        for i, match in enumerate(matches):
            claims.append({
                "id": f"T1_{i+1}",
                "text": match.strip(),
                "tier": "I"
            })
        
        return claims
    
    def _extract_validation_logs(self, text: str) -> Dict[str, Dict[str, Any]]:
        """Extract validation logs from BUILDER output."""
        logs = {}
        
        # Pattern: log_id: "L1" ... test_procedure: ...
        log_pattern = r'log_id:\s*["\']?(L\d+)["\']?\s*.*?test_procedure:\s*\|?\s*(.+?)(?=expected_result:|pass_fail_gate:|$)'
        matches = re.findall(log_pattern, text, re.DOTALL | re.IGNORECASE)
        
        for log_id, procedure in matches:
            logs[log_id] = {
                "id": log_id,
                "procedure": procedure.strip()
            }
        
        return logs
    
    def _validate_claim(self, claim: Dict[str, Any], 
                       validation_logs: Dict[str, Dict[str, Any]]) -> ValidationResult:
        """Validate a single claim."""
        
        claim_id = claim["id"]
        claim_text = claim["text"]
        
        # Try to find executable code in claim
        code = self._extract_code(claim_text)
        
        if not code:
            # No executable code found - demote to Tier II
            return ValidationResult(
                claim_id=claim_id,
                claim_text=claim_text,
                original_tier="I",
                validated_tier="II",
                status=ValidationStatus.DEMOTED,
                expected="Executable test",
                actual="No testable code found",
                execution_time_ms=0,
                error_message="Claim lacks computational certificate - demoted to Tier II"
            )
        
        # Check code safety
        if not self._is_safe_code(code):
            return ValidationResult(
                claim_id=claim_id,
                claim_text=claim_text,
                original_tier="I",
                validated_tier="REJECTED",
                status=ValidationStatus.UNSAFE,
                expected="Safe code",
                actual="Unsafe patterns detected",
                execution_time_ms=0,
                error_message="Code contains potentially unsafe operations"
            )
        
        # Execute code
        success, result, error, exec_time = self._execute_code(code)
        
        if error:
            return ValidationResult(
                claim_id=claim_id,
                claim_text=claim_text,
                original_tier="I",
                validated_tier="II",
                status=ValidationStatus.ERROR,
                expected="Successful execution",
                actual=str(result),
                execution_time_ms=exec_time,
                error_message=error
            )
        
        # For now, assume execution success = validation pass
        # In production, would compare to expected values
        return ValidationResult(
            claim_id=claim_id,
            claim_text=claim_text,
            original_tier="I",
            validated_tier="I",
            status=ValidationStatus.PASSED,
            expected="Computation completes",
            actual=str(result)[:200] if result else "None",
            execution_time_ms=exec_time
        )
    
    def _extract_code(self, text: str) -> Optional[str]:
        """Extract Python code from text."""
        # Look for code blocks
        code_pattern = r'```(?:python)?\s*\n(.+?)```'
        matches = re.findall(code_pattern, text, re.DOTALL)
        
        if matches:
            return matches[0]
        
        # Look for inline code that looks executable
        inline_pattern = r'`([^`]+)`'
        inline_matches = re.findall(inline_pattern, text)
        
        for match in inline_matches:
            if any(kw in match for kw in ['def ', 'import ', 'return ', '=']):
                return match
        
        return None
    
    def _is_safe_code(self, code: str) -> bool:
        """Check if code is safe to execute."""
        for pattern in UNSAFE_PATTERNS:
            if re.search(pattern, code):
                return False
        return True
    
    def _execute_code(self, code: str) -> Tuple[bool, Any, Optional[str], float]:
        """
        Execute code in sandboxed environment.
        
        Returns: (success, result, error, execution_time_ms)
        """
        import time
        
        # Wrap code to capture result
        wrapped_code = f"""
import math
import numpy as np
from decimal import Decimal
from fractions import Fraction

__result__ = None
__error__ = None

try:
{self._indent_code(code)}
    __result__ = "EXECUTION_COMPLETE"
except Exception as e:
    __error__ = str(e)

print(f"RESULT:{{__result__}}")
print(f"ERROR:{{__error__}}")
"""
        
        start_time = time.time()
        
        try:
            # Write to temp file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(wrapped_code)
                temp_path = f.name
            
            # Execute with timeout
            result = subprocess.run(
                ['python', temp_path],
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            
            exec_time = (time.time() - start_time) * 1000
            
            # Parse output
            stdout = result.stdout
            stderr = result.stderr
            
            if "ERROR:None" in stdout and "RESULT:" in stdout:
                # Extract result
                result_match = re.search(r'RESULT:(.+)', stdout)
                result_value = result_match.group(1) if result_match else None
                return True, result_value, None, exec_time
            else:
                error_match = re.search(r'ERROR:(.+)', stdout)
                error_msg = error_match.group(1) if error_match else stderr
                return False, None, error_msg, exec_time
                
        except subprocess.TimeoutExpired:
            return False, None, f"Execution timeout ({self.timeout}s)", self.timeout * 1000
        except Exception as e:
            return False, None, str(e), 0
        finally:
            # Cleanup
            if 'temp_path' in locals():
                try:
                    os.unlink(temp_path)
                except:
                    pass
    
    def _indent_code(self, code: str, spaces: int = 4) -> str:
        """Indent code block."""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))


# ═══════════════════════════════════════════════════════════════════════════════
# INTEGRATION WITH ORACLE LOOP
# ═══════════════════════════════════════════════════════════════════════════════

def validate_builder_output(builder_output: str) -> Dict[str, Any]:
    """
    Hook for ORACLE orchestrator to validate BUILDER output.
    
    Returns dict with:
    - passed: bool
    - report: ValidatorReport as dict
    - message: summary string
    """
    validator = TierIValidator()
    report = validator.validate(builder_output)
    
    passed = report.overall_status in ["FULLY_VALIDATED", "PARTIAL_VALIDATION", "NO_TESTABLE_CLAIMS"]
    
    if report.kill_switches_triggered > 0:
        message = f"❌ KILL-SWITCH TRIGGERED: {report.results[0].kill_switch_triggered}"
    elif report.overall_status == "FULLY_VALIDATED":
        message = f"✅ All {report.tier_I_validated} Tier I claims validated"
    elif report.overall_status == "PARTIAL_VALIDATION":
        message = f"⚠️ {report.tier_I_validated} validated, {report.tier_II_demoted} demoted to Tier II"
    elif report.overall_status == "VALIDATION_FAILED":
        message = f"❌ {report.tier_I_failed} Tier I claims FAILED validation"
    else:
        message = "ℹ️ No testable Tier I claims found"
    
    return {
        "passed": passed,
        "report": report.to_dict(),
        "message": message
    }


# ═══════════════════════════════════════════════════════════════════════════════
# CLI TESTING
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Test with sample BUILDER output
    sample_output = """
BUILD:
  artifact:
    content: |
      [Tier I] The sum of first n integers is n*(n+1)/2
      
      ```python
      def sum_integers(n):
          return n * (n + 1) // 2
      
      # Verify for n=100
      assert sum_integers(100) == 5050
      ```
      
      [Tier II] This pattern may extend to higher-order sums
      
  validation_logs:
    - log_id: "L1"
      test_procedure: |
        Run sum_integers(100) and verify result
      expected_result: 5050
"""
    
    print("ORACLE BOT - Tier I Validator Test")
    print("=" * 50)
    
    result = validate_builder_output(sample_output)
    
    print(f"\nStatus: {result['message']}")
    print(f"Passed: {result['passed']}")
    print(f"\nFull Report:")
    print(json.dumps(result['report'], indent=2))
