# ORACLE BOT 🔮

> **Multi-Agent Cognitive Architecture with Epistemic Tier Discipline**

A 5-agent sequential brainstorming system inspired by ChatDev, designed for rigorous problem decomposition and solution synthesis.

```
┌─────────────────────────────────────────────────────────────┐
│                    ORACLE ORCHESTRATOR                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
   DECOMPOSER → EXPLORER → CRITIC → BUILDER → INTEGRATOR
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd oracle-bot
pip install -r requirements.txt --break-system-packages
```

### 2. Run (Mock Mode - No API Key Needed)

```bash
python app.py
```

Open http://localhost:5000 in your browser.

### 3. Run with Real LLMs

**Anthropic Claude:**
```bash
export ANTHROPIC_API_KEY=your_key_here
# Edit CONFIG in app.py: "llm_backend": "anthropic"
python app.py
```

**OpenAI:**
```bash
export OPENAI_API_KEY=your_key_here
# Edit CONFIG in app.py: "llm_backend": "openai"
python app.py
```

**Ollama (Local):**
```bash
# Start Ollama first: ollama serve
# Edit CONFIG in app.py: "llm_backend": "ollama", "ollama_model": "llama2"
python app.py
```

**LM Studio:**
```bash
# Start LM Studio server on localhost:1234
# Edit CONFIG in app.py: "llm_backend": "lmstudio"
python app.py
```

---

## 🧠 Agent Architecture

### The 5 Agents

| Agent | Role | Output |
|-------|------|--------|
| **DECOMPOSER** | Break problem into atomic subtasks | Task DAG with dependencies |
| **EXPLORER** | Generate 5 diverse solution candidates | Conventional, Contrarian, First-Principles, Analogical, Adversarial approaches |
| **CRITIC** | Adversarial evaluation | Viability scores, kill recommendations, objections |
| **BUILDER** | Construct the actual deliverable | Code, proof, plan, or analysis |
| **INTEGRATOR** | Synthesize final response | Confidence score, open obligations, next steps |

### Epistemic Tiers (Non-Negotiable)

- **Tier I**: Proven/tested claims only
- **Tier II**: Falsifiable conjectures with protocols
- **Tier III**: Heuristics (must be labeled, cannot justify)

---

## 🔧 Configuration

Edit the `CONFIG` dict in `app.py`:

```python
CONFIG = {
    "llm_backend": "anthropic",  # mock | anthropic | openai | ollama | lmstudio
    "model": "claude-sonnet-4-20250514",
    "api_base_url": "https://api.anthropic.com",
    "max_tokens": 4096,
    "temperature": 0.7,
}
```

---

## 📁 Project Structure

```
oracle-bot/
├── app.py              # Main Flask application + LLM router
├── requirements.txt    # Python dependencies
├── templates/
│   └── index.html      # Frontend interface
├── prompts/            # (Optional) External prompt files
├── sessions/           # Saved session exports
└── README.md
```

---

## 🎯 Usage Examples

### Example 1: System Design
```
Query: "Design a distributed caching system that handles 1M requests/second 
with < 10ms latency"
```

### Example 2: Research Question
```
Query: "Analyze the trade-offs between proof-of-stake and proof-of-work 
consensus mechanisms for environmental sustainability"
```

### Example 3: Code Architecture
```
Query: "Design a plugin system for a Python CLI tool that allows 
third-party extensions without modifying core code"
```

---

## 🔌 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Main interface |
| `/api/config` | GET | Get current config |
| `/api/config` | POST | Update config |
| `/api/run-agent` | POST | Run single agent |
| `/api/run-full-cycle` | POST | Run complete 5-agent cycle |
| `/api/save-session` | POST | Save session to file |

---

## 🛠️ Extending ORACLE

### Add a New Agent

1. Add to `AGENT_ORDER` list in `app.py`
2. Add prompt to `AGENT_PROMPTS` dict
3. Add icon to `AGENT_ICONS` in `index.html`
4. Update pipeline visualization

### Custom LLM Backend

Add a new function in `app.py`:

```python
def query_my_custom_llm(prompt: str) -> str:
    # Your implementation
    return response

# Add to query_llm() router
```

---

## 📊 Progress Scoring

The INTEGRATOR calculates a progress score:

```
+1.0  per Tier I obligation discharged (proven/tested)
+0.5  per Tier II conjecture with falsification protocol
-2.0  per scope leak / unjustified leap caught
```

This converts "thinking harder" into a controlled, measurable process.

---

## ⚡ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl + Enter` | Run ORACLE cycle |

---

## 🔒 Epistemic Safeguards

ORACLE enforces:
- **No continuum claims** without explicit assumption labeling
- **Open Obligations list** in every output
- **Kill recommendations** when approaches are fundamentally flawed
- **Confidence thresholds** (< 0.5 triggers iteration)

---

## 📝 License

MIT License - Use freely, modify extensively.

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Submit a PR with clear description

---

Built with epistemic discipline. 🔮
